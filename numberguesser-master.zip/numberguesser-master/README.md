# NumberGuesser App

Windows console application written in C# / .NET - Simple number guessing game. This app is from the C# / .NET tutorial on YouTube by Brad Traversy

### Version
1.0.0

## Usage
Run bin/NumberGuesser.exe